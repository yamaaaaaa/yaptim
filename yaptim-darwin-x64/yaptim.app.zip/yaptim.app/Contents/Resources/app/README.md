
# yaptim Image optimizer for HTML markup

画像のトリミング最適化などをおこないます。

1. イラストレーターのアセット書き出し時のクリッピングマスクによる余白を取り除きます。(png > png)
2. ベタ塗りのPNG(元からまたは1でトリミングしてベタになったもの)はクオリティー95%のjpgに変換します。
3. imageOptimで最適化します。

## 特記

- brewでインストールしたimagemagickに依存しています。
- imageOptimのcliに依存しています。


